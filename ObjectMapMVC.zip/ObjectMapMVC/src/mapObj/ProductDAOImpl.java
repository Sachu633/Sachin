package mapObj;

import java.security.GeneralSecurityException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import mapObj.Product;

public class ProductDAOImpl 
{
	public String addProduct(Product p1)
	{
		try
		{
			Class.forName("org.h2.Driver");
			Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
			PreparedStatement pst = con.prepareStatement("insert into product values(?,?,?,?)");
			
			pst.setInt(1, p1.getId());
			pst.setString(2, p1.getName());
			pst.setInt(3, p1.getPrice());
			pst.setString(4, p1.getDes());
			
			pst.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println("Exception cought..... : "+e);
		}
		return "DATA is ADDEDD Successfully......";
	}
	
	/*public void updatePro()
	{
		
	}
	public void deletePro()
	{
		
	}
	public List<Product> listPro()
	{
		List<Product> list = new ArrayList<Product>();
		
		return list;
	}*/
}
