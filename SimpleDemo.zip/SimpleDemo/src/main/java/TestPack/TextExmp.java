package TestPack;

public class TextExmp 
{

	public static void main(String[] args) 
	{
		TextExmp te1 = new TextExmp();
		TextExmp te2 = new TextExmp();
		
		int m1 = te1.hashCode();
		int m2 = te2.hashCode();
		
		System.out.println("Hash code of te1 is: "+m1);
		System.out.println("Hash code of te2 is: "+m2);
		if(te1.equals(te2))
		{
			System.out.println("Object are equal.....");
		}
		else
		{
			System.out.println("Objects are not equal...");
		}
	}

}
