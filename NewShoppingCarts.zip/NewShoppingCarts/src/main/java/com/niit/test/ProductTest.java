package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.dao.ProductDAO;
import com.niit.model.Product;

public class ProductTest {

	public static void main(String[] args) 
	{
	
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		System.out.println("success");
		Product product=(Product) context.getBean("product");
		
		product.setId("17");
		product.setName("laptop");
		product.setPrice(45000);
		product.setDes("lenovo");
		product.setCategory_id("sgdhs");
		product.setSupplier_id("shdjsjs");
		
       }

}