package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;



public class CartTest 
{

	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CartDAO cartDAO = (CartDAO) context.getBean("cartDAO");
		System.out.println("success");
		Cart cart=(Cart) context.getBean("cart");
		
		
		cart.setPrice(20000);
		cart.setProduct_id("c1");
		cart.setQuantity(1);
		cart.setStatus("60pxl");
		cart.setUser_id(01);
		
		cartDAO.addCart(cart);
	}

}
