package com.niit.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Cart;
import com.niit.model.User;
@EnableTransactionManagement
//connects to DB by taking attributes from POJO class
@Repository("cartDAO")
public class CartDAOImpl implements CartDAO
{  //IT WILL CREATE AN OBJECT WITHOUT HELP OF NEW OPERATOER
	@Autowired
	private SessionFactory sessionfactory;
	
	public CartDAOImpl(SessionFactory sessionfactory)
	{
		this.sessionfactory=sessionfactory;
	}
	//used to transaction from model to dao class
	@Transactional
	public void addCart(Cart cart)
	{
		sessionfactory.getCurrentSession().saveOrUpdate(cart);
	}
}
