package com.niit.dao;

import java.util.List;
import com.niit.model.Cart;


public interface CartDAO 
{
	public void addCart(Cart cart);
	public void delete(int id);
	public Cart getCart(String id);
	public List<Cart> list();
	
}
