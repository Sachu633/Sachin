package com.niit.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.CartDAO;
import com.niit.dao.CategoryDAO;
import com.niit.dao.ProductDAO;
import com.niit.dao.UserDAO;
import com.niit.model.Cart;
import com.niit.model.Category;
import com.niit.model.Product;
import com.niit.model.User;

@Controller
public class CartController 
{
	
 @Autowired(required=true)
 Cart cart;
 
 @Autowired(required=true)
 CartDAO cartDAO;
 
 @Autowired(required=true)
 CategoryDAO categoryDAO;
 
 @Autowired(required=true)
 ProductDAO productDAO;
 
 @Autowired(required=true)
 Product product;
 
 @Autowired(required=true)
 UserDAO userDAO;
	
 	@Autowired(required=true)
   private User user;
   
   
	@RequestMapping(value = "/myCart", method = RequestMethod.GET)
	public String myCart(Model model)
	{
		model.addAttribute("cart",new Cart());
		model.addAttribute("cartList",this.cartDAO.list());
		model.addAttribute("category",new Category());
		model.addAttribute("categoryList",this.categoryDAO.list());
		model.addAttribute("displayCart","true");
		return "cart";
		
		
	}
	
	@RequestMapping(value = "cart/add/{p_id}", method = RequestMethod.GET)
	public String addToCart(@PathVariable("p_id") String id, HttpServletRequest request )
	{
		
		Product product=productDAO.getProduct(id);
		//User user = userDAO.getUser(id);
		Cart cart=new Cart();
		cart.setPrice(product.getPrice());
		cart.setProduct_name(product.getName());	
		cart.setQuantity(1);
		cart.setUser_id(user.getId());
		cart.setStatus("");
		
		cartDAO.addCart(cart);
		
		return "redirect:/";
		
		
	}
}