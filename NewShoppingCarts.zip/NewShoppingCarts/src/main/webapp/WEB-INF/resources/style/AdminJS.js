function setup() {
  createCanvas(windowWidth, windowHeight);
  background('#2F343B');
  strokeWeight(0.1);
  frameRate(24);
}

function draw() {
  for (var i = 0; i < width; i++) {
    var w = random(width); //random X
    var h = random(height); //random Y

    var colorList = [ "#703030", "#2F343B", "#7E827A", "#E3CDA4", "#C77966"]; //color list
    var c = round(random(4));  // select random color
    stroke(colorList[c]); //set fill color
    line( 0, w, w*2, h*2);//draw line
    smooth(); //just smooth
    }
}
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}