package dataPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class TestConnect111 
{

	public static void main(String[] args) throws Exception
	{
	int id,phone;
	String name,address;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter your details:.....");
	
	id = sc.nextInt();
	name = sc.next();
	phone = sc.nextInt();
	address = sc.next();
	
	Class.forName("org.h2.Driver");
	Connection con = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","");
	PreparedStatement pst = con.prepareStatement("insert into customervalues values(?,?,?,?)");
	
	pst.setInt(1, id);
	pst.setString(2, name);
	pst.setInt(3, phone);
	pst.setString(4, address);

	pst.executeUpdate();
	pst.close();
	con.close();
	
	System.out.println("DATA IS ADDED.....");
	}

}
