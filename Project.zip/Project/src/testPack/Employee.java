package testPack;

public class Employee 
{
	int id, phoneNo; 
	public void addEmp()
	{
		id = 21;
		phoneNo = 89704;
	}
	public void printEmp(int salary)
	{
		System.out.println("Employee id is:"+id);
		System.out.println("Employee phone no is:"+phoneNo);
		System.out.println("Employee salary is:"+salary);
	}
	public void description(String name, int phnum)
	{
		System.out.println("Employee name is:"+name);
		System.out.println("Employee description is:"+phnum);
	}
	public static void main(String[] args) 
	{
		Employee emp = new Employee();
		emp.addEmp();
		emp.printEmp(100000);
		emp.description("SACHIN", 89704);
		}
	
		
}


