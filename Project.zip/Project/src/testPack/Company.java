package testPack;

public class Company 
{
	String dname;
	
	
	
	public String getDname() 
	{
		return dname;
	}



	public void setDname(String dname) 
	{
		this.dname = dname;
	}



	public static void main(String[] args) 
	{
		Company com = new Company();
		Department dep = new Department();
	    com.setDname("Tally");
	    String n = com.getDname();
	    dep.description(n, 89704);
	    
	    
	    Department dep1 = new Department();
	    com.setDname("Accounts");
	    String n1 = com.getDname();
	    dep1.description(n1, 89704);
	    
	    
	    

	}

}
