package testPack;

public class Department 
{
	String departmentAddress;
	public void addDep()
	{
		departmentAddress = "Malleshwaram";
	}
	public void printDep(int id)
	{
		System.out.println("Department address is:"+departmentAddress);
		System.out.println("Employee id is:"+id);
	}
	public void description(String name, int number)
	{
		System.out.println("Department name is :"+name);
		System.out.println("Department number is:"+number);
	}
	public static void main(String[] args) 
	{
		Department dep = new Department();
		dep.addDep();
		dep.printDep(201);
		dep.description("NIIT", 28301);
	}

}
