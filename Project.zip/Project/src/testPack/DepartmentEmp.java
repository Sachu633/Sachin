package testPack;

public class DepartmentEmp 
{
	String dname;
	
	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public static void main(String[] args)
	{
		DepartmentEmp depex = new DepartmentEmp();
		Employee emp = new Employee();
		depex.setDname("NIIT");
		String n = depex.getDname();
		emp.description("Rahul", 85213);
		
		
		Employee emp1 = new Employee();
		depex.setDname("NIIT");
		String n1 = depex.getDname();
		emp1.description("Praveen", 55265);
		
		
		Employee emp2 = new Employee();
		depex.setDname("NIIT");
		String n2 = depex.getDname();
		emp2.description("Sachin", 95113);
	}

}
