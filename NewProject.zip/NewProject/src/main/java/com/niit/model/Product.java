package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity 
@Table(name = "product")
@Component
public class Product
{
	@Id
	private String P_id;
	
	@NotEmpty(message = "please enter name")
	private String P_name;
	
	@NotEmpty(message = "please enter prices")
	private String P_prices;
	
	@NotEmpty(message = "please enter des")
	private String P_description;

	public String getP_id() {
		return P_id;
	}

	public void setP_id(String p_id) {
		P_id = p_id;
	}

	public String getP_name() {
		return P_name;
	}

	public void setP_name(String p_name) {
		P_name = p_name;
	}

	public String getP_prices() {
		return P_prices;
	}

	public void setP_prices(String p_prices) {
		P_prices = p_prices;
	}

	public String getP_description() {
		return P_description;
	}

	public void setP_description(String p_description) {
		P_description = p_description;
	}

}