package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;
import com.niit.model.User;

public class UserTest {

	public static void main(String[] args)
	{
      AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
      context.scan("com.niit");
      context.refresh();
      UserDAO userDAO= (UserDAO) context.getBean("userDAO");
      System.out.println("success");
      User user = (User) context.getBean("user");

      user.setName("SACHIN");
      user.setAddress("BLORE");
      user.setEmail("sachulovelyatar@gmail.com");
      user.setPhonenum("8970499633");
      user.setPassword("89704sachu");
      
      userDAO.addUser(user);
	}

}
