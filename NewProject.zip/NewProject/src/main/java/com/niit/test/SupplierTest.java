package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.SupplierDAO;
import com.niit.model.Supplier;

public class SupplierTest 
{

	
	public static void main(String[] args)
	{
      AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
      context.scan("com.niit");
      context.refresh();
      
      SupplierDAO supplierDAO= (SupplierDAO) context.getBean("supplierDAO");
      System.out.println("success");
      
      Supplier supplier= (Supplier)context.getBean("supplier");

      supplier.setS_id("001");
      supplier.setS_name("pra");
      supplier.setS_address("serui");
      supplier.setS_phone("9620744");
      
      supplierDAO.addSupplier(supplier);
	}

}
