package com.niit.dao;

import java.util.List;

import com.niit.model.Category;

public interface CategoryDAO 
{
	public void addCategory(Category category);
	public void getCategory(String id);
	public void Delete(String id); 
	public List<Category>list();
	public Category getmyName(String name);
}
