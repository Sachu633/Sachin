package com.niit.dao;

import com.niit.model.Supplier;


public interface SupplierDAO 
{
    public void addSupplier(Supplier supplier);
    
    	
     
}
