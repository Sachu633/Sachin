package com.niit.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.dao.UserDAO;
import com.niit.model.User;




@Controller
public class HomeControler 
{
	@Autowired
	UserDAO userDAO;
	
	@RequestMapping("/")
	public String getlanding()
	{
		return "index";
	}
	
	@RequestMapping("/register")
	public ModelAndView register(Model m)
	{
		m.addAttribute("user", new User());
		ModelAndView model = new ModelAndView("signUp");
		return model;
	} 


	@RequestMapping(value="register/add", method=RequestMethod.POST)
	public String addUser(@ModelAttribute User user)
	{
		userDAO.addUser(user);
		ModelAndView mv = new ModelAndView("/");
		mv.addObject("success","REGISTRATION IS SUCCESSFULL");
		return "redirect:/";
	}
	
	@RequestMapping("login")
	public String getlogin()
	{
		return "logIn";
	}
	
	@RequestMapping("admin")
	public String getAdmin()
	{
		return "adminHome";
	}
}
