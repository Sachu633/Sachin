package com.niit.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

@Controller
public class CategoryControler 
{
	@Autowired
	CategoryDAO categoryDAO;
	@Autowired
	Category category;
	
	//for add and update category both
		@RequestMapping(value="/category/add", method=RequestMethod.POST)
		public String addCategory(@ModelAttribute("category") Category category){

			
			category.addCategory(category);
			
			
			return "redirect:/category";
			//return "category";
			

		}
}
